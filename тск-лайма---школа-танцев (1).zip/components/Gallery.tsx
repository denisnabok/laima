import React from 'react';

export const Gallery: React.FC = () => {
  const photos = [
    {
      url: "https://images.unsplash.com/photo-1519925610903-3810643e61bf?q=80&w=1000&auto=format&fit=crop",
      title: "Эмоции победы",
      size: "large"
    },
    {
      url: "https://images.unsplash.com/photo-1546421845-3477706f5e8c?q=80&w=800&auto=format&fit=crop",
      title: "Грация и пластика", 
      size: "small"
    },
    {
      url: "https://images.unsplash.com/photo-1535525153412-5a42439a210d?q=80&w=800&auto=format&fit=crop",
      title: "Спортивный характер",
      size: "small"
    },
    {
      url: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=800&auto=format&fit=crop",
      title: "Первые шаги",
      size: "small"
    },
    {
      url: "https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?q=80&w=800&auto=format&fit=crop", 
      title: "Европейская программа",
      size: "small"
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-slate-900 mb-4">Жизнь клуба в фото</h2>
          <p className="text-slate-600">Яркие моменты тренировок и соревнований</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 auto-rows-[200px]">
            {/* Simulate a masonry grid layout */}
            {photos.map((photo, idx) => (
                <div 
                    key={idx} 
                    className={`relative rounded-2xl overflow-hidden group ${photo.size === 'large' ? 'md:col-span-2 md:row-span-2' : 'md:col-span-1 md:row-span-1'}`}
                >
                    <img 
                        src={photo.url} 
                        alt={photo.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <span className="text-white font-bold text-lg">{photo.title}</span>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};
import React, { useState } from 'react';
import { DailySchedule } from '../types';

const scheduleData: DailySchedule[] = [
  {
    day: "Понедельник",
    items: [
      { time: "18:00", group: "Группа 4-6 лет (45 минут)" },
      { time: "18:00", group: "МКГ «Е» класс (60 мин)" },
      { time: "19:00", group: "Hip-Hop начинающие (с 7 лет)" },
      { time: "19:45", group: "Группа СВД (спорт высших достижений) / Европейская программа (75 мин)" },
    ]
  },
  {
    day: "Вторник",
    items: [
      { time: "17:00", group: "Группа 4-6 лет (45 минут)" },
      { time: "18:00", group: "МКГ (младшая конкурсная группа) (60 мин)" },
      { time: "18:00", group: "ОФП высокий уровень (60 мин)" },
      { time: "18:30", group: "Hip-Hop продолжающие" },
      { time: "19:00", group: "Группа 7-9 лет (45 минут)" },
      { time: "19:00", group: "ОФП средний уровень" },
      { time: "19:30", group: "Hip-Hop продвинутые" },
      { time: "20:00", group: "ОФП начинающий уровень (60 мин)" },
    ]
  },
  {
    day: "Среда",
    items: [
      { time: "18:00", group: "Группа 4-6 лет (45 минут)" },
      { time: "18:00", group: "МКГ «Е» класс (60 мин)" },
      { time: "19:00", group: "Hip-Hop начинающие" },
      { time: "19:30", group: "Группа СВД / Латина (90 мин)" },
    ]
  },
  {
    day: "Четверг",
    items: [
      { time: "17:00", group: "Группа 4-6 лет (45 минут)" },
      { time: "18:00", group: "МКГ (младшая конкурсная группа) (60 мин)" },
      { time: "18:30", group: "Hip-Hop продолжающие" },
      { time: "19:00", group: "Группа 7-9 лет (45 минут)" },
      { time: "19:30", group: "Hip-Hop продвинутые" },
      { time: "20:00", group: "Группа СВД / Прогон Европейская программа (60 мин)" },
    ]
  },
  {
    day: "Пятница",
    items: [
      { time: "16:00", group: "ОФП высокий уровень (60 мин)" },
      { time: "17:00", group: "ОФП средний уровень (60 мин)" },
      { time: "18:00", group: "ОФП высокий уровень (60 мин)" },
      { time: "20:00", group: "ОФП начинающий уровень (60 мин)" },
    ]
  }
];

export const Schedule: React.FC = () => {
  const [activeDay, setActiveDay] = useState("Понедельник");

  const currentSchedule = scheduleData.find(d => d.day === activeDay);

  return (
    <section id="schedule" className="py-24 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-slate-900 mb-4">Расписание занятий</h2>
          <p className="text-slate-600">
            Индивидуальные уроки доступны с 9:00 до 21:00.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {scheduleData.map((day) => (
            <button
              key={day.day}
              onClick={() => setActiveDay(day.day)}
              className={`px-6 py-3 rounded-full text-sm font-bold transition-all ${
                activeDay === day.day
                  ? 'bg-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/30 scale-105'
                  : 'bg-white text-slate-500 hover:bg-fuchsia-50 hover:text-fuchsia-600 border border-slate-200'
              }`}
            >
              {day.day}
            </button>
          ))}
        </div>

        <div className="bg-white rounded-3xl shadow-xl shadow-purple-100 border border-slate-100 overflow-hidden min-h-[300px]">
          <div className="p-6 sm:p-10">
             <h3 className="text-2xl font-bold text-slate-800 mb-8 flex items-center">
                <span className="w-2 h-8 bg-fuchsia-500 rounded-full mr-3"></span>
                {activeDay}
             </h3>
             {currentSchedule ? (
               <div className="space-y-3">
                 {currentSchedule.items.map((item, idx) => (
                   <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between p-5 rounded-xl bg-slate-50 hover:bg-fuchsia-50 transition-colors border border-transparent hover:border-fuchsia-100 group">
                     <div className="flex items-center gap-5">
                        <div className="bg-white text-fuchsia-700 border border-fuchsia-100 text-sm font-bold px-4 py-2 rounded-lg group-hover:bg-fuchsia-600 group-hover:text-white transition-colors shadow-sm min-w-[80px] text-center">
                          {item.time}
                        </div>
                        <span className="font-medium text-slate-800 text-lg">{item.group}</span>
                     </div>
                   </div>
                 ))}
               </div>
             ) : (
               <p>Расписание не найдено</p>
             )}
          </div>
          <div className="bg-slate-900 p-6 text-center">
            <p className="text-slate-400 text-sm">
              * Расписание может меняться. Уточняйте актуальную информацию у тренеров.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
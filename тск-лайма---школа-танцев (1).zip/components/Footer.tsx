import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          <div className="text-center md:text-left">
            <h3 className="text-white text-2xl font-bold font-serif mb-2">ТСК «ЛАЙМА»</h3>
            <p className="text-sm">Школа спортивных бальных танцев.</p>
            <p className="text-sm">Основано в 1989 году.</p>
          </div>

          <div className="flex gap-8 text-sm">
            <a href="#about" className="hover:text-white transition-colors">О клубе</a>
            <a href="#schedule" className="hover:text-white transition-colors">Расписание</a>
            <a href="#contact" className="hover:text-white transition-colors">Контакты</a>
          </div>

          <div className="text-center md:text-right text-xs">
            <p>&copy; {new Date().getFullYear()} ТСК Лайма. Все права защищены.</p>
            <p className="mt-1">Нижний Новгород, ул. Карла Маркса, 17</p>
          </div>

        </div>
      </div>
    </footer>
  );
};
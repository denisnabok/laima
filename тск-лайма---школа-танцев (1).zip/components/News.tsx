import React from 'react';
import { Award, Calendar } from 'lucide-react';
import { NewsItem } from '../types';

const news: NewsItem[] = [
  {
    id: 1,
    date: "08-09 Ноября",
    title: "Кубок Кремля 2025",
    content: [
      "Наши лаймовцы показали отличные результаты в Нижнем Новгороде!",
      "🥇 Саламатин Александр и Стрекаловская Александра — 1 место (Дети-2 Е класс стандарт)",
      "🥈 Шулаев Тимур и Колпакова Екатерина — 2 место (Дети-2 двоеборье)",
      "🏆 Сисягин Антон и Никулина София — финалисты"
    ],
    tags: ["Турнир", "Победа"]
  },
  {
    id: 2,
    date: "27-28 Сентября",
    title: "Кубок главы Чувашской Республики",
    content: [
      "В Чебоксарах прошли квалификационные соревнования.",
      "🥉 Шулаев Тимур и Колпакова Екатерина — 3 место (Дети 2+1, 8 танцев)",
      "🥈 Шулаев Тимур и Колпакова Екатерина — 2 место (Европейская программа)"
    ],
    tags: ["Выезд", "Призеры"]
  },
  {
    id: 3,
    date: "2025",
    title: "Russian Open DanceSport Championships",
    content: [
      "Лаймовцы завершили выступления на одном из самых масштабных турниров года!",
      "Все пары достойно выступили в латиноамериканской программе, показав собранность и отличную энергетику."
    ],
    tags: ["ROC-2025", "Масштаб"]
  }
];

export const News: React.FC = () => {
  return (
    <section id="news" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <span className="text-fuchsia-600 font-bold tracking-wider uppercase text-sm">События</span>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-slate-900 mt-2">Новости клуба</h2>
          </div>
          <a href="#" className="text-fuchsia-600 font-medium hover:text-fuchsia-800 flex items-center gap-1 transition-colors">
            Архив новостей &rarr;
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {news.map((item) => (
            <article key={item.id} className="flex flex-col bg-white border border-slate-200 rounded-2xl overflow-hidden hover:shadow-2xl hover:shadow-purple-100 transition-all duration-300 group">
              <div className="bg-slate-50 p-6 flex items-center gap-3 border-b border-slate-100 group-hover:bg-fuchsia-50/50 transition-colors">
                <div className="bg-white p-2 rounded-lg shadow-sm text-fuchsia-600">
                    <Calendar className="w-5 h-5" />
                </div>
                <span className="font-bold text-slate-700">{item.date}</span>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex gap-2 mb-4">
                    {item.tags?.map(tag => (
                        <span key={tag} className="px-2.5 py-1 bg-fuchsia-50 text-fuchsia-700 text-xs font-bold rounded-md uppercase tracking-wider border border-fuchsia-100">{tag}</span>
                    ))}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-fuchsia-700 transition-colors">{item.title}</h3>
                <div className="space-y-3 text-slate-600 text-sm flex-1">
                  {item.content.map((line, idx) => (
                    <p key={idx} className={line.includes("место") || line.includes("финалисты") ? "font-semibold text-slate-800 bg-slate-50 p-2 rounded border-l-2 border-fuchsia-400" : ""}>
                      {line}
                    </p>
                  ))}
                </div>
              </div>
              <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 mt-auto">
                <span className="flex items-center text-slate-500 text-sm font-medium">
                    <Award className="w-4 h-4 mr-2 text-fuchsia-500" />
                    ТСК «Лайма»
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
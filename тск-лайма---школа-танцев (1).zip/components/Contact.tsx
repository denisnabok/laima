import React from 'react';
import { Phone, MapPin, Globe } from 'lucide-react';

export const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div>
            <div className="inline-block p-3 bg-purple-100 rounded-2xl mb-6">
                <Phone className="w-8 h-8 text-purple-600" />
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-slate-900 mb-6">
              Приходите знакомиться!
            </h2>
            <p className="text-lg text-slate-600 mb-10 leading-relaxed">
              Первое занятие — отличный способ узнать, подходит ли вам наша школа. 
              Записывайтесь по телефону или приходите к нам в гости.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-5 p-6 bg-white rounded-2xl shadow-sm border border-slate-100 hover:border-purple-200 transition-colors">
                <div className="bg-fuchsia-50 p-3 rounded-full text-fuchsia-600 shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-lg mb-1">Наш адрес</h4>
                  <p className="text-slate-600">
                    г. Нижний Новгород, Мещера<br />
                    ул. Карла Маркса, 17, школа №176<br />
                    <span className="text-sm text-fuchsia-600 font-medium mt-1 block">ТСК «Лайма» (Главное здание)</span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-5 p-6 bg-white rounded-2xl shadow-sm border border-slate-100 hover:border-purple-200 transition-colors">
                <div className="bg-fuchsia-50 p-3 rounded-full text-fuchsia-600 shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-lg mb-1">Телефоны</h4>
                  <div className="flex flex-col gap-2">
                    <a href="tel:+79625108652" className="text-slate-700 hover:text-fuchsia-600 transition-colors font-medium flex items-center gap-2">
                        +7 (962) 510-86-52 <span className="text-slate-400 font-normal text-sm">— Влада Андреевна</span>
                    </a>
                    <a href="tel:+79200130944" className="text-slate-700 hover:text-fuchsia-600 transition-colors font-medium flex items-center gap-2">
                        +7 (920) 013-09-44 <span className="text-slate-400 font-normal text-sm">— Светлана Николаевна</span>
                    </a>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-5 p-6 bg-white rounded-2xl shadow-sm border border-slate-100 hover:border-purple-200 transition-colors">
                <div className="bg-fuchsia-50 p-3 rounded-full text-fuchsia-600 shrink-0">
                  <Globe size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-lg mb-1">Мы в соцсетях</h4>
                  <a href="https://vk.link/laima_nn" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline font-medium">
                    vk.link/laima_nn
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-3xl shadow-2xl shadow-purple-100/50 border border-white">
            <div className="w-full h-[500px] bg-slate-100 rounded-2xl overflow-hidden relative">
               <iframe 
                 src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2211.4648275028296!2d43.9468!3d56.3345!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTbCsDIwJzA0LjIiTiA0M8KwNTYnNDguNSJF!5e0!3m2!1sen!2sru!4v1635765432100!5m2!1sen!2sru" 
                 width="100%" 
                 height="100%" 
                 style={{border:0}} 
                 allowFullScreen 
                 loading="lazy"
                 title="Map Location"
                 className="grayscale opacity-90 hover:grayscale-0 hover:opacity-100 transition-all duration-700"
               ></iframe>
               <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur px-5 py-3 rounded-xl shadow-lg text-sm font-bold text-slate-900 border border-slate-200">
                 <div className="text-fuchsia-600 text-xs uppercase mb-1">Локация</div>
                 Школа №176
               </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { Testimonial } from '../types';

const reviews: Testimonial[] = [
  {
    id: 1,
    name: "Мария Благодарящева",
    role: "Родитель, сын занимается 5 лет",
    date: "8 октября",
    text: "Клуб расположен прямо в школе — огромный плюс для работающих родителей. Тренеры стали не просто наставниками, а примером для подражания. Здесь не только тренируются, но и вместе отмечают праздники. Это место, где дети растут и становятся частью большой дружной команды!"
  },
  {
    id: 2,
    name: "Оксана Беспалова",
    role: "Родитель",
    date: "9 октября",
    text: "Здесь царит тёплая атмосфера, профессиональные педагоги умеют заинтересовать танцами. Занятия проходят увлекательно и динамично, дети быстро осваивают новые движения. Рекомендую всем родителям, кто хочет видеть своего ребенка счастливым и активным!"
  },
  {
    id: 3,
    name: "Екатерина Х",
    role: "Родитель, занимается 5-й год",
    date: "11 октября",
    text: "За 5 лет ни разу не было мысли бросить. Самое главное — результат стоит того. Осанка, умение держать себя, смелость. Низкий поклон тренерам за объединение и создание такой команды!"
  }
];

export const Testimonials: React.FC = () => {
  return (
    <section id="reviews" className="py-24 bg-slate-900 text-white relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-fuchsia-700 rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-blob"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-700 rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-blob animation-delay-2000"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Отзывы родителей</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-fuchsia-600 to-purple-600 mx-auto rounded-full mb-6"></div>
          <p className="text-slate-300 max-w-2xl mx-auto text-lg">
            Уже более 37 лет нам доверяют воспитание детей. Вот что говорят о нас родители.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review) => (
            <div key={review.id} className="bg-slate-800/40 backdrop-blur-md p-8 rounded-3xl border border-slate-700 hover:border-fuchsia-500/50 transition-all duration-300 hover:bg-slate-800/60">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-1 bg-slate-900/50 px-3 py-1 rounded-full">
                   {[...Array(5)].map((_, i) => (
                     <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />
                   ))}
                </div>
                <Quote className="text-fuchsia-500 w-10 h-10 opacity-30" />
              </div>
              <p className="text-slate-300 mb-8 leading-relaxed italic">
                "{review.text}"
              </p>
              <div className="mt-auto flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-fuchsia-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg">
                    {review.name[0]}
                </div>
                <div>
                    <h4 className="font-bold text-white">{review.name}</h4>
                    <div className="text-sm text-fuchsia-300">{review.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
           <a href="https://vk.link/laima_nn" target="_blank" rel="noreferrer" className="inline-block border border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300 px-8 py-3 rounded-full hover:bg-fuchsia-500 hover:text-white transition-all">
             Читать все отзывы ВКонтакте
           </a>
        </div>
      </div>
    </section>
  );
};
import React from 'react';
import { CalendarCheck, Star } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <div className="relative bg-slate-900 text-white overflow-hidden min-h-[85vh] flex items-center">
      {/* Abstract Purple Background - mimicking the banner */}
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=2029&auto=format&fit=crop')] bg-cover bg-center opacity-40"></div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-purple-900/80 to-fuchsia-900/60 mix-blend-multiply"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24">
        <div className="lg:w-3/4">
          {/* Stylized Logo Text resembling the banner */}
          <div className="mb-8 animate-fade-in-up">
             <h1 className="font-serif text-6xl sm:text-8xl lg:text-9xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white via-fuchsia-200 to-purple-200 drop-shadow-lg" style={{lineHeight: 0.8}}>
               LAIMA
             </h1>
             <p className="text-lg sm:text-xl lg:text-2xl tracking-[0.2em] sm:tracking-[0.4em] text-fuchsia-300 mt-2 font-light uppercase">
               Professional Dance Center
             </p>
          </div>

          <div className="inline-flex items-center px-4 py-2 rounded-full bg-fuchsia-900/40 border border-fuchsia-500/30 backdrop-blur-md text-fuchsia-100 text-sm font-semibold mb-8">
            <Star size={16} className="mr-2 text-yellow-400 fill-yellow-400" />
            37 лет успеха и воспитания чемпионов
          </div>
          
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-medium text-white mb-8 max-w-3xl leading-snug">
            Ведущая школа спортивных бальных танцев <br/>
            <span className="text-fuchsia-400">в Нижнем Новгороде</span>
          </h2>
          
          <div className="flex flex-col sm:flex-row gap-5">
            <a
              href="#contact"
              className="inline-flex justify-center items-center px-8 py-4 border border-transparent text-base font-bold rounded-full text-white bg-gradient-to-r from-fuchsia-600 to-purple-600 hover:from-fuchsia-500 hover:to-purple-500 md:text-lg transition-all shadow-lg shadow-fuchsia-900/50 transform hover:-translate-y-1"
            >
              <CalendarCheck className="mr-2 h-5 w-5" />
              Записаться на пробное
            </a>
            <a
              href="#schedule"
              className="inline-flex justify-center items-center px-8 py-4 border border-white/30 text-base font-bold rounded-full text-white hover:bg-white/10 md:text-lg transition-all backdrop-blur-md"
            >
              Посмотреть расписание
            </a>
          </div>

          <div className="mt-16 grid grid-cols-2 gap-8 sm:grid-cols-3 text-center sm:text-left border-t border-white/10 pt-8">
            <div>
              <div className="text-4xl font-serif font-bold text-white">1989</div>
              <div className="text-sm text-purple-200 mt-1 font-medium uppercase tracking-wider">Год основания</div>
            </div>
            <div>
              <div className="text-4xl font-serif font-bold text-white">800+ м²</div>
              <div className="text-sm text-purple-200 mt-1 font-medium uppercase tracking-wider">Танцевальных залов</div>
            </div>
            <div>
              <div className="text-4xl font-serif font-bold text-white">30+</div>
              <div className="text-sm text-purple-200 mt-1 font-medium uppercase tracking-wider">Тренеров-профи</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'О клубе', href: '#about' },
    { name: 'Преимущества', href: '#features' },
    { name: 'Галерея', href: '#gallery' },
    { name: 'Расписание', href: '#schedule' },
    { name: 'Новости', href: '#news' },
    { name: 'Отзывы', href: '#reviews' },
    { name: 'Контакты', href: '#contact' },
  ];

  return (
    <nav className="bg-white/90 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-purple-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-fuchsia-600 to-purple-700 rounded-full flex items-center justify-center text-white font-bold text-xl font-serif shadow-lg">
                Л
              </div>
              <span className="font-bold text-2xl tracking-tight text-slate-900">ТСК «ЛАЙМА»</span>
            </div>
          </div>
          
          <div className="hidden lg:flex items-center space-x-6">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-slate-600 hover:text-fuchsia-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="tel:+79625108652"
              className="bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white px-5 py-2.5 rounded-full text-sm font-medium hover:from-fuchsia-700 hover:to-purple-700 transition-all shadow-md hover:shadow-fuchsia-200 flex items-center gap-2"
            >
              <Phone size={16} />
              <span>Записаться</span>
            </a>
          </div>

          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-slate-600 hover:text-fuchsia-600 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t border-gray-100 absolute w-full shadow-xl">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block px-3 py-2 rounded-md text-base font-medium text-slate-600 hover:text-fuchsia-600 hover:bg-purple-50"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="tel:+79625108652"
              className="block w-full text-center mt-4 bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white px-4 py-3 rounded-lg text-base font-medium"
            >
              Позвонить
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};